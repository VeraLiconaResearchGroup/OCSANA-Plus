Use this directory as a template to create your Algorun container.
For more information about how to do it, please refer to our [How-to Guide](http://algorun.org/how-to.html)
